/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

// Lazy load pages
const Login = lazy(() => import('./pages/Auth/Login'));
const Register = lazy(() => import('./pages/Auth/Register'));
const Dashboard = lazy(() => import('./pages/Dashboard/Dashboard'));
const Ranking = lazy(() => import('./pages/Ranking/Ranking'));
const Profile = lazy(() => import('./pages/Profile/Profile'));
const Networking = lazy(() => import('./pages/Networking/Networking'));
const Challenges = lazy(() => import('./pages/Challenges/Challenges'));
const Badges = lazy(() => import('./pages/Badges/Badges'));

const Layout = lazy(() => import('./components/Layout'));

export default function App() {
  return (
    <Router>
      <AnimatePresence mode="wait">
        <Suspense fallback={
          <div className="flex h-screen w-full items-center justify-center bg-slate-50">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-blue-600 text-3xl font-bold tracking-tight"
            >
              SkillMatch.
            </motion.div>
          </div>
        }>
          <Routes>
            {/* Auth Routes */}
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />

            {/* Main App Routes */}
            <Route path="/" element={<Layout />}>
              <Route index element={<Navigate to="/dashboard" replace />} />
              <Route path="dashboard" element={<Dashboard />} />
              <Route path="ranking" element={<Ranking />} />
              <Route path="profile" element={<Profile />} />
              <Route path="networking" element={<Networking />} />
              <Route path="challenges" element={<Challenges />} />
              <Route path="badges" element={<Badges />} />
            </Route>

            {/* Fallback */}
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </Suspense>
      </AnimatePresence>
    </Router>
  );
}

