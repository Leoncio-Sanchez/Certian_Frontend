import { Target, Zap, Clock, Users, ArrowRight, Gamepad2, Award } from 'lucide-react';
import { motion } from 'framer-motion';

const featuredChallenges = [
  {
    id: 1,
    title: 'Sistema de Misión Crítica: Core Bancario',
    company: 'Stripe',
    difficulty: 'Avanzado',
    hours: 80,
    time: '80h avanzado',
    participants: 12,
    details: 'Diseña e implementa un motor de conciliación bancaria capaz de procesar 50,000 transacciones por segundo con consistencia ACID garantizada.',
    img: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&q=80&w=1200'
  }
];

const normalChallenges = [
  { 
    title: 'Audit de Seguridad ISO 27001', 
    company: 'Cloudflare', 
    hours: 20, 
    level: 'Básico', 
    duration: '20 básico',
    description: 'Realiza un test de penetración exhaustivo y propone parches para vulnerabilidades OWASP Top 10 en un entorno staging.',
    img: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&q=80&w=1000'
  },
  { 
    title: 'Migración a Arquitectura Serverless', 
    company: 'AWS', 
    hours: 40, 
    level: 'Medio', 
    duration: '40 medio',
    description: 'Rediseña una aplicación monolítica legacy a funciones Lambda, optimizando el inicio en frío y el costo operativo mensual.',
    img: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=1000'
  },
  { 
    title: 'Implementación de LLM On-Premise', 
    company: 'DeepMind', 
    hours: 80, 
    level: 'Avanzado', 
    duration: '80 avanzado',
    description: 'Despliega y fine-tunea un modelo Llama-3 para una base de conocimientos privada, asegurando privacidad total de datos.',
    img: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&q=80&w=1000'
  },
  { 
    title: 'Diseño de Compilador de Alto Rendimiento', 
    company: 'NVIDIA', 
    hours: 80, 
    level: 'Avanzado', 
    duration: '80 avanzado',
    description: 'Desarrolla optimizaciones de bajo nivel para un compilador de C++ enfocado en procesamiento paralelo masivo en GPUs.',
    img: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&q=80&w=1000'
  }
];

export default function Challenges() {
  return (
    <div className="space-y-12 pb-20 max-w-6xl mx-auto px-4">
      <header className="space-y-4">
        <span className="section-label">Retos y Validaciones Técnicas</span>
        <h1 className="text-5xl font-bold text-slate-900 leading-tight">Explora Desafíos <br /><span className="text-blue-600">Académicos de Élite.</span></h1>
        <p className="text-slate-500 max-w-lg font-medium leading-relaxed text-lg">
          Resuelve problemas técnicos reales propuestos por las mejores empresas de tecnología. 
          Cada éxito te otorga <span className="font-bold text-blue-700">Horas de Validación</span> efectivas.
        </p>
        <div className="bg-blue-50 border border-blue-100 p-4 rounded-xl inline-flex items-center gap-3">
          <Award className="text-blue-600" size={20} />
          <p className="text-sm text-blue-800 font-bold">
            Meta: Cada 200 horas acumuladas puedes solicitar un certificado oficial.
          </p>
        </div>
      </header>

      {/* Featured Challenge */}
      <section>
        <div className="flex items-center justify-between mb-8 px-2">
          <h2 className="text-2xl font-bold flex items-center gap-2 text-slate-800">
            <Zap className="text-blue-600" size={24} /> Desafío Destacado
          </h2>
          <span className="text-xs uppercase tracking-widest text-slate-400 font-bold">Insignia Especial</span>
        </div>

        {featuredChallenges.map(c => (
          <div key={c.id} className="relative group overflow-hidden rounded-3xl bg-white border border-slate-200 flex flex-col lg:flex-row shadow-xl hover:shadow-2xl transition-shadow duration-500">
            <div className="w-full lg:w-2/5 h-[300px] lg:h-auto overflow-hidden">
               <img 
                 src={c.img} 
                 alt={c.title} 
                 className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105" 
                 referrerPolicy="no-referrer"
               />
               <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 via-transparent to-transparent" />
            </div>
            <div className="flex-1 p-8 lg:p-12 flex flex-col justify-between">
              <div className="space-y-6">
                <div className="flex flex-wrap items-center gap-4">
                  <span className="flex items-center gap-2 text-slate-500 text-xs uppercase tracking-widest font-bold"><Clock size={14} className="text-blue-600" /> {c.time}</span>
                  <span className="flex items-center gap-2 text-slate-500 text-xs uppercase tracking-widest font-bold border-l border-slate-200 pl-4"><Users size={14} className="text-blue-600" /> {c.participants} aplicantes</span>
                </div>
                
                <h3 className="text-3xl lg:text-4xl font-bold leading-tight text-slate-900">
                  {c.title} <br />
                  <span className="text-blue-600 text-2xl">Vía {c.company}</span>
                </h3>
                
                <p className="text-slate-600 font-medium leading-relaxed max-w-xl text-lg">
                  {c.details}
                </p>
              </div>

              <div className="mt-12 flex items-end justify-between border-t border-slate-100 pt-8">
                <div className="flex items-center gap-4">
                   <div className="p-4 rounded-2xl bg-blue-600 text-white shadow-lg shadow-blue-600/30">
                     <Clock size={28} />
                   </div>
                   <div className="space-y-0.5">
                     <p className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">Recompensa</p>
                     <p className="text-3xl font-bold text-slate-900 leading-none">{c.hours} <span className="text-blue-600 uppercase text-xs">HORAS</span></p>
                   </div>
                </div>
                <button className="group relative flex items-center gap-3 bg-slate-900 text-white px-8 py-4 rounded-xl font-bold hover:bg-blue-700 transition-all active:scale-95 shadow-lg shadow-slate-900/20">
                  <span className="relative z-10">Aplicar ahora</span>
                  <ArrowRight size={18} className="relative z-10 transition-transform group-hover:translate-x-1" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </section>

      {/* Grid of Challenges */}
      <section className="space-y-8 pt-6">
        <h2 className="text-2xl font-bold px-2 text-slate-800">Explorar por Horas</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {normalChallenges.map((c, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-white rounded-2xl border border-slate-200 group hover:border-blue-300 hover:shadow-xl transition-all duration-300 cursor-pointer overflow-hidden flex flex-col"
            >
              <div className="h-56 overflow-hidden relative bg-slate-100">
                <img 
                  src={c.img} 
                  alt={c.title} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-slate-900/5 group-hover:bg-transparent transition-colors" />
                <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-sm px-3 py-1.5 rounded-full flex items-center gap-1.5 shadow-md border border-white/50">
                  <Clock size={12} className="text-blue-600" />
                  <span className="font-black text-[10px] uppercase tracking-wider text-slate-800">{c.hours} Horas</span>
                </div>
              </div>

              <div className="p-8 flex-1 flex flex-col">
                <div className="flex items-center justify-between mb-4">
                   <span className="text-[10px] uppercase tracking-[0.2em] font-bold text-blue-600">{c.company}</span>
                </div>
                
                <h4 className="text-xl font-bold text-slate-900 leading-tight group-hover:text-blue-700 transition-colors">{c.title}</h4>
                <p className="text-slate-500 text-sm mt-3 font-medium leading-relaxed flex-1">{c.description}</p>
                
                <div className="mt-8 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="bg-blue-50 text-blue-700 px-3 py-1.5 rounded-lg flex items-center gap-2">
                      <Target size={14} />
                      <span className="text-xs font-bold uppercase tracking-wider">{c.duration}</span>
                    </div>
                  </div>
                  <button className="text-[11px] uppercase tracking-widest font-bold text-blue-600 group-hover:underline flex items-center gap-1">
                    Detalles <ArrowRight size={12} />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Bottom CTA */}
      <div className="text-center pt-8">
        <div className="bg-slate-100/50 rounded-2xl p-8 border border-dashed border-slate-300">
           <p className="text-slate-500 text-sm font-medium mb-4 italic">¿Quieres proponer un reto académico basado en proyectos reales?</p>
           <button className="text-slate-900 font-bold bg-white border border-slate-200 px-8 py-3 rounded-xl hover:bg-slate-50 transition-all text-sm uppercase tracking-widest shadow-sm">
             Contactar Staff Académico
           </button>
        </div>
      </div>
    </div>
  );
}
