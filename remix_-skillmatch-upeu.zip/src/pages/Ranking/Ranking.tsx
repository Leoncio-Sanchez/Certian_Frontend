import { Trophy, Medal, Crown, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';

const topUsers = [
  { rank: 1, name: 'Sofia Rodriguez', hours: '840', university: 'UPeU', skill: 'IA & Machine Learning', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=400' },
  { rank: 2, name: 'Marco Chen', hours: '720', university: 'Stanford', skill: 'Finanzas Digitales', avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=400' },
  { rank: 3, name: 'Alex Thompson', hours: '690', university: 'Harvard', skill: 'Arquitectura Cloud', avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=400' },
];

const listUsers = [
  { rank: 4, name: 'Maria Garcia', hours: '580', university: 'UPM', skill: 'Ciberseguridad', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=400' },
  { rank: 5, name: 'Luca Rossi', hours: '450', university: 'Bocconi', skill: 'Marketing Digital', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=400' },
  { rank: 6, name: 'Emma Watson', hours: '420', university: 'Oxford', skill: 'Software Arch', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=400' },
  { rank: 7, name: 'Juan Diego', hours: '140', university: 'UPeU', skill: 'Web Fullstack', isUser: true, avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=400' },
  { rank: 8, name: 'Hans Müller', hours: '130', university: 'TUM', skill: 'Robótica', avatar: 'https://images.unsplash.com/photo-1531384441138-2736e62e0919?auto=format&fit=crop&q=80&w=400' },
];

export default function Ranking() {
  return (
    <div className="max-w-5xl mx-auto space-y-12 pb-20 px-4">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="space-y-4">
          <span className="section-label">Ranking Académico Global</span>
          <h1 className="text-5xl font-bold text-slate-900 leading-tight">Muro de Élite <br /><span className="text-blue-600">Académica.</span></h1>
          <p className="text-slate-500 max-w-md font-medium leading-relaxed italic">
            Compite con los mejores estudiantes. Acumula horas validadas para escalar posiciones en el Hall of Fame.
          </p>
        </div>
        <div className="flex gap-4">
          <button className="bg-white border border-slate-200 px-6 py-2.5 rounded-xl text-xs font-bold uppercase tracking-widest hover:border-blue-500 transition-all shadow-sm">Este Mes</button>
          <button className="bg-blue-600 text-white px-6 py-2.5 rounded-xl text-xs font-bold uppercase tracking-widest shadow-md">Histórico</button>
        </div>
      </div>

      {/* Podium */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-8 items-end pt-10">
        {/* Silver */}
        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-white border border-slate-200 rounded-3xl p-10 text-center order-2 md:order-1 h-[350px] flex flex-col justify-end relative shadow-sm hover:shadow-xl transition-all">
          <div className="absolute top-0 right-0 p-6 opacity-5 text-slate-900"><Medal size={120} /></div>
          <div className="w-20 h-20 rounded-full mx-auto mb-6 border-2 border-slate-200 overflow-hidden">
            <img src={topUsers[1].avatar} alt={topUsers[1].name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          </div>
          <h3 className="text-xl font-bold text-slate-900">{topUsers[1].name}</h3>
          <p className="text-xs text-slate-400 font-bold uppercase tracking-tighter mb-4">{topUsers[1].university}</p>
          <div className="bg-slate-50 py-2 rounded-xl font-bold text-slate-400 text-sm uppercase tracking-widest">2° Lugar</div>
          <p className="text-3xl mt-4 font-bold text-slate-900">{topUsers[1].hours}h</p>
        </motion.div>

        {/* Gold */}
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="bg-white border-2 border-blue-600 rounded-[40px] p-12 text-center order-1 md:order-2 h-[440px] flex flex-col justify-end relative shadow-2xl shadow-blue-600/10">
          <div className="absolute -top-12 left-1/2 -translate-x-1/2 text-blue-600 animate-bounce duration-[2000ms]"><Crown size={64} /></div>
          <div className="w-28 h-28 rounded-full mx-auto mb-8 border-4 border-blue-600 shadow-xl shadow-blue-600/20 overflow-hidden">
            <img src={topUsers[0].avatar} alt={topUsers[0].name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          </div>
          <h3 className="text-3xl font-bold text-slate-900">{topUsers[0].name}</h3>
          <p className="text-sm text-blue-600 font-black uppercase tracking-widest mb-6">{topUsers[0].university}</p>
          <div className="bg-blue-600 py-4 rounded-2xl font-black text-white text-lg shadow-lg shadow-blue-600/30">1° LUGAR</div>
          <p className="text-5xl mt-6 font-bold text-blue-600">{topUsers[0].hours}h</p>
        </motion.div>

        {/* Bronze */}
        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="bg-white border border-slate-200 rounded-3xl p-10 text-center order-3 md:order-3 h-[320px] flex flex-col justify-end relative shadow-sm hover:shadow-xl transition-all">
          <div className="absolute top-0 right-0 p-6 opacity-5 text-amber-900"><Medal size={100} /></div>
          <div className="w-16 h-16 rounded-full mx-auto mb-6 border-2 border-amber-200 overflow-hidden">
            <img src={topUsers[2].avatar} alt={topUsers[2].name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          </div>
          <h3 className="text-lg font-bold text-slate-900">{topUsers[2].name}</h3>
          <p className="text-xs text-slate-400 font-bold uppercase tracking-tighter mb-4">{topUsers[2].university}</p>
          <div className="bg-amber-50 py-2 rounded-xl font-bold text-amber-600 text-sm uppercase tracking-widest">3° Lugar</div>
          <p className="text-2xl mt-4 font-bold text-slate-900">{topUsers[2].hours}h</p>
        </motion.div>
      </section>

      {/* List */}
      <section className="pt-20 space-y-6">
        <h2 className="text-2xl font-bold px-4 text-slate-800">Clasificación General</h2>
        <div className="space-y-3">
          {listUsers.map((user) => (
            <div 
              key={user.rank} 
              className={`flex items-center justify-between p-6 px-10 rounded-2xl transition-all border ${user.isUser ? 'bg-blue-600 border-blue-600 text-white shadow-xl shadow-blue-600/20' : 'bg-white border-slate-100 hover:border-slate-200 hover:bg-slate-50'}`}
            >
              <div className="flex items-center gap-8">
                <span className={`font-bold text-2xl ${user.isUser ? 'text-blue-100' : (user.rank <= 3 ? 'text-blue-600' : 'text-slate-300')}`}>
                  {user.rank < 10 ? `0${user.rank}` : user.rank}
                </span>
                <div className="w-12 h-12 rounded-full overflow-hidden border border-slate-200 flex-shrink-0">
                  <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
                <div>
                  <h4 className="font-bold flex items-center gap-3 text-lg leading-none">
                    {user.name}
                    {user.isUser && <span className="bg-white text-blue-600 text-[9px] font-black uppercase tracking-widest px-3 py-1 rounded-full shadow-sm">TÚ</span>}
                  </h4>
                  <p className={`text-[10px] uppercase tracking-widest font-bold mt-1.5 ${user.isUser ? 'text-blue-100' : 'text-slate-400'}`}>
                    {user.university} <span className="mx-2 opacity-30">|</span> {user.skill}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-12 text-right">
                <div className={`flex items-center gap-2 ${user.isUser ? 'text-blue-100' : 'text-green-500'} hidden sm:flex`}>
                  <TrendingUp size={16} />
                  <span className="text-xs font-bold">+12</span>
                </div>
                <div className="flex flex-col items-end">
                  <span className={`text-2xl font-bold tracking-tight ${user.isUser ? 'text-white' : 'text-slate-900'}`}>{user.hours}h</span>
                  <p className={`text-[9px] font-black uppercase tracking-widest ${user.isUser ? 'text-blue-100' : 'text-slate-400'}`}>Horas Validadas</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
