import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

export default function Login() {
  return (
    <div className="flex h-screen w-full bg-white">
      <div className="hidden lg:flex w-1/2 relative overflow-hidden bg-slate-50">
        <div className="absolute inset-0 bg-gradient-to-tr from-blue-600/10 via-transparent to-transparent opacity-50" />
        <div className="absolute top-20 left-20 z-10">
          <h1 className="text-8xl font-black text-slate-900 leading-tight opacity-5 select-none tracking-tighter">
            SkillMatch. <br /> Académico.
          </h1>
        </div>
        <div className="flex items-center justify-center w-full p-20 relative z-20">
          <div className="max-w-md">
            <h2 className="text-5xl font-bold text-slate-900 mb-8 leading-tight">
              Diseñado para los que buscan la <span className="text-blue-600 italic">excelencia académica.</span>
            </h2>
            <p className="text-slate-500 font-medium leading-relaxed text-lg">
              Únete a la red elite de estudiantes de la UPeU. 
              Valida tus habilidades con retos basados en proyectos reales.
            </p>
          </div>
        </div>
      </div>
      
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 bg-white border-l border-slate-100">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-sm space-y-10"
        >
          <div className="space-y-4">
            <h3 className="text-4xl font-bold text-slate-900 tracking-tight">Inicia Sesión</h3>
            <p className="text-slate-400 font-medium font-serif italic text-lg leading-relaxed">Cada sello es un paso hacia tu éxito profesional.</p>
          </div>

          <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-widest font-bold text-slate-400">Email Universitario</label>
              <input 
                type="email" 
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 focus:border-blue-500 focus:bg-white outline-none transition-all placeholder:text-slate-300 font-medium"
                placeholder="nombre@upeu.edu.pe"
              />
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-[10px] uppercase tracking-widest font-bold text-slate-400">Contraseña</label>
                <button className="text-[10px] text-blue-600 uppercase tracking-widest font-bold hover:underline">Olvide mi contraseña</button>
              </div>
              <input 
                type="password" 
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 focus:border-blue-500 focus:bg-white outline-none transition-all placeholder:text-slate-300 font-medium"
                placeholder="••••••••"
              />
            </div>

            <Link 
              to="/dashboard"
              className="w-full block text-center bg-slate-900 hover:bg-blue-600 text-white py-5 rounded-xl font-bold transition-all transform active:scale-[0.98] shadow-xl shadow-slate-900/10"
            >
              Acceder al Portal Académico
            </Link>
          </form>

          <p className="text-center text-sm text-slate-500 font-medium">
            ¿Aún no eres miembro? <Link to="/register" className="text-blue-600 font-bold underline">Unete ahora</Link>
          </p>

          <Link to="/" className="flex items-center gap-2 text-slate-400 hover:text-blue-600 transition-colors text-xs uppercase tracking-widest font-bold">
            <ArrowLeft size={16} />
            Volver al Inicio
          </Link>
        </motion.div>
      </div>
    </div>
  );
}
