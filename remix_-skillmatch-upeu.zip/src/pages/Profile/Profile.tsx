import { 
  Briefcase, 
  MapPin, 
  Calendar, 
  Mail,
  ShieldCheck,
  Star,
  Settings,
  Award,
  Zap,
  BookOpen,
  PieChart,
  Clock,
  Shield
} from 'lucide-react';
import { motion } from 'framer-motion';

export default function Profile() {
  const skills = [
    { name: 'React', level: 90 },
    { name: 'Node.js', level: 85 },
    { name: 'TypeScript', level: 80 },
    { name: 'Python', level: 75 },
    { name: 'PostgreSQL', level: 70 },
    { name: 'Machine Learning', level: 65 },
  ];

  const certifications = [
    { 
      id: 'UPeU', 
      title: 'Desarrollo Web Full Stack', 
      provider: 'Universidad Peruana Unión', 
      date: 'Mayo 2026',
      icon: 'UPeU',
      color: 'bg-blue-600'
    },
    { 
      id: 'TC', 
      title: 'Excelencia en Frontend', 
      provider: 'TechCorp Solutions', 
      date: 'Abril 2026',
      icon: 'TC',
      color: 'bg-violet-600'
    },
    { 
      id: 'DI', 
      title: 'Machine Learning Avanzado', 
      provider: 'DataInsights Peru', 
      date: 'Marzo 2026',
      icon: 'DI',
      color: 'bg-emerald-600'
    },
    { 
      id: 'RT', 
      title: 'API Design & Development', 
      provider: 'RetailTech Solutions', 
      date: 'Febrero 2026',
      icon: 'RT',
      color: 'bg-orange-600'
    },
  ];

  const stats = [
    { label: 'Retos Completados', value: '24', icon: Award, color: 'text-blue-500 bg-blue-50' },
    { label: 'Certificaciones', value: '18', icon: ShieldCheck, color: 'text-violet-500 bg-violet-50' },
    { label: 'Calificación Promedio', value: '4.8', icon: Star, color: 'text-emerald-500 bg-emerald-50' },
    { label: 'Horas de Práctica', value: '340h', icon: BookOpen, color: 'text-orange-500 bg-orange-50' },
  ];

  return (
    <div className="max-w-[1400px] mx-auto space-y-8 pb-20 px-4">
      {/* Header Title */}
      <div className="pt-4">
        <h1 className="text-2xl font-bold text-slate-800">Mi Perfil</h1>
        <p className="text-slate-400 text-sm mt-1">Gestiona tu información y visualiza tus certificaciones</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column (4/12) */}
        <div className="lg:col-span-4 space-y-8">
          {/* Profile Basic Info */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-10 flex flex-col items-center">
              <div className="w-32 h-32 rounded-full overflow-hidden shadow-lg shadow-violet-200 mb-6 group transition-transform hover:scale-105 border-4 border-white">
                <img 
                  src="https://images.unsplash.com/photo-1599566150163-29194dcaad36?auto=format&fit=crop&q=80&w=400" 
                  alt="Avatar" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <h2 className="text-2xl font-bold text-slate-800">Juan Delgado</h2>
              <p className="text-slate-500 font-medium">Estudiante de Ingeniería</p>
              
              <div className="mt-4 flex items-center gap-2 bg-slate-50 px-3 py-1 rounded-full border border-slate-100">
                <Star size={14} className="text-amber-500 fill-amber-500" />
                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-600">Nivel: Elite</span>
              </div>

              <div className="w-full h-px bg-slate-100 my-8" />

              <div className="w-full space-y-4 px-4 pb-4">
                {[
                  { icon: Mail, text: 'juan.delgado@upeu.edu.pe' },
                  { icon: Briefcase, text: 'Universidad Peruana Unión' },
                  { icon: Zap, text: 'Ing. de Sistemas - 8vo Ciclo' },
                  { icon: MapPin, text: 'Lima, Perú' },
                  { icon: Calendar, text: 'Miembro desde Enero 2025' },
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-3 text-slate-500">
                    <item.icon size={16} className="shrink-0" />
                    <span className="text-xs font-medium">{item.text}</span>
                  </div>
                ))}
              </div>

              <button className="w-full mt-6 py-4 bg-[#7c3aed] hover:bg-violet-700 text-white rounded-xl font-bold transition-all shadow-lg shadow-violet-200 active:scale-[0.98]">
                Editar Perfil
              </button>
            </div>
          </div>

          {/* Habilidades Card */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-8">
            <div className="flex items-center gap-3 mb-8">
              <div className="p-2 bg-blue-50 rounded-lg">
                <PieChart size={18} className="text-blue-600" />
              </div>
              <h3 className="font-bold text-slate-800">Habilidades</h3>
            </div>
            
            <div className="space-y-6">
              {skills.map((skill) => (
                <div key={skill.name} className="space-y-2">
                  <div className="flex justify-between items-center text-[10px] font-bold text-slate-400 uppercase tracking-tight">
                    <span className="text-slate-700">{skill.name}</span>
                    <span>{skill.level}%</span>
                  </div>
                  <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${skill.level}%` }}
                      transition={{ duration: 1, ease: 'easeOut' }}
                      className="h-full bg-gradient-to-r from-blue-600 to-[#7c3aed]"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column (8/12) */}
        <div className="lg:col-span-8 space-y-8">
          
          {/* Estadísticas de Rendimiento */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-8">
            <div className="flex items-center justify-between mb-8">
              <h3 className="font-bold text-slate-800">Estadísticas de Rendimiento</h3>
              <div className="flex items-center gap-2 text-[10px] font-bold text-blue-600 uppercase tracking-widest bg-blue-50 px-3 py-1 rounded-full">
                <Clock size={12} />
                Próximo Certificado: 60h restantes
              </div>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
              {stats.map((stat) => (
                <div key={stat.label} className="text-center group">
                  <div className={`w-14 h-14 mx-auto ${stat.color} rounded-2xl flex items-center justify-center mb-4 transition-transform group-hover:scale-110 shadow-sm`}>
                    <stat.icon size={24} />
                  </div>
                  <p className="text-2xl font-bold text-slate-900 leading-none">{stat.value}</p>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tight mt-2">{stat.label}</p>
                </div>
              ))}
            </div>

            <div className="space-y-3">
              <div className="flex justify-between items-center text-[11px] font-bold uppercase tracking-tight">
                <span className="text-slate-500">Progreso para Certificado de Excelencia (200h)</span>
                <span className="text-blue-600">140h / 200h (70%)</span>
              </div>
              <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden p-0.5">
                <div className="h-full bg-blue-600 rounded-full" style={{ width: '70%' }} />
              </div>
              <p className="text-[10px] text-slate-400 font-medium italic">Cada 200 horas de práctica validadas se emite un nuevo Certificado de Excelencia Académica.</p>
            </div>
          </div>

          {/* Sello de Excelencia (200h Milestone) */}
          <section className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#7c3aed] to-[#4f46e5] p-10 text-white shadow-xl shadow-violet-200">
            <div className="absolute top-0 right-0 w-1/3 h-full opacity-10 pointer-events-none">
              <Shield size={200} className="absolute -top-10 -right-10 text-white" />
            </div>
            
            <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
              <div className="space-y-4 text-center md:text-left">
                <h3 className="text-2xl font-bold">Sello de Excelencia Universidad Peruana Unión</h3>
                <p className="text-violet-100 text-sm font-medium leading-relaxed max-w-xl">
                  Has demostrado un rendimiento excepcional y compromiso con la excelencia académica. 
                  Este sello reconoce tu esfuerzo al alcanzar el hito de las <span className="font-bold underline">200 horas validadas</span>.
                </p>
                
                <div className="flex items-center gap-4 pt-4">
                  <div className="bg-white/20 p-3 rounded-xl border border-white/10 backdrop-blur-md">
                     <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center text-xs font-bold text-[#7c3aed]">
                          UPeU
                        </div>
                        <div className="text-left">
                           <p className="text-xs font-bold">Certificación Oficial</p>
                           <p className="text-[10px] text-violet-100">Mayo 2026</p>
                        </div>
                     </div>
                  </div>
                </div>
              </div>

              <div className="relative shrink-0">
                <div className="w-32 h-32 rounded-full border-4 border-white/20 flex items-center justify-center bg-white/10 backdrop-blur-md shadow-2xl relative">
                  <div className="absolute inset-0 rounded-full border-4 border-dashed border-white/40 animate-spin-slow" />
                  <Award size={64} className="text-amber-400 drop-shadow-lg" />
                </div>
              </div>
            </div>
          </section>

        </div>
      </div>
    </div>
  );
}
