import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Trophy, 
  User, 
  Users, 
  Target, 
  Award, 
  LogOut,
  ChevronRight
} from 'lucide-react';
import { motion } from 'framer-motion';

const menuItems = [
  { path: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/networking', label: 'Networking', icon: Users },
  { path: '/challenges', label: 'Retos', icon: Target },
  { path: '/ranking', label: 'Ranking', icon: Trophy },
  { path: '/badges', label: 'Mis Sellos', icon: Award },
  { path: '/profile', label: 'Mi Perfil', icon: User },
];

export default function Sidebar() {
  return (
    <aside className="w-64 border-r border-slate-200 flex flex-col h-full bg-white">
      <div className="p-8">
        <h1 className="text-2xl font-bold text-blue-600 tracking-tight">SkillMatch</h1>
        <p className="text-[10px] uppercase tracking-widest text-slate-400 font-bold -mt-0.5">PORTAL ESTUDIANTIL</p>
      </div>

      <nav className="flex-1 px-4 space-y-1">
        <p className="section-label px-4 mt-4">Gestión</p>
        {menuItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) => `
              flex items-center justify-between px-4 py-3 rounded-lg transition-all duration-300 group
              ${isActive 
                ? 'bg-violet-600 text-white shadow-lg shadow-violet-200' 
                : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'}
            `}
          >
            <div className="flex items-center gap-3">
              <item.icon size={20} className={`transition-transform group-hover:scale-110 ${item.path === window.location.pathname ? '' : ''}`} />
              <span className="text-sm font-semibold">{item.label}</span>
            </div>
            <ChevronRight size={14} className="opacity-0 group-hover:opacity-100 transition-opacity" />
          </NavLink>
        ))}
      </nav>

      <div className="p-6 mt-auto">
        <div className="border border-slate-100 rounded-xl p-4 bg-slate-50 transition-all hover:border-violet-100 group cursor-pointer">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-violet-600 flex items-center justify-center font-bold text-white shadow-md shadow-violet-200">JD</div>
            <div className="overflow-hidden">
              <p className="text-sm font-bold text-slate-900 truncate">Juan Delgado</p>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-tight">UPeU Student</p>
            </div>
          </div>
        </div>
        <button className="flex items-center gap-2 text-slate-400 hover:text-red-600 text-sm mt-6 px-4 transition-colors font-bold uppercase tracking-wider text-[11px]">
          <LogOut size={16} />
          <span>Cerrar Sesión</span>
        </button>
      </div>
    </aside>
  );
}
