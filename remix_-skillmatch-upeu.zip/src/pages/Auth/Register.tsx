import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowLeft, CheckCircle2 } from 'lucide-react';

export default function Register() {
  return (
    <div className="flex min-h-screen w-full bg-white">
      <div className="hidden lg:flex w-1/3 p-20 bg-blue-600 flex-col justify-between">
        <div>
          <h1 className="text-4xl font-bold text-white leading-tight tracking-tighter">SkillMatch.</h1>
          <p className="text-[10px] uppercase tracking-widest text-blue-100 font-bold">Solicitud de Admisión</p>
        </div>
        
        <div className="space-y-12">
          <h2 className="text-6xl font-bold text-white leading-tight">Empieza tu viaje <br /> <span className="text-blue-100 italic">al siguiente nivel.</span></h2>
          <div className="space-y-6">
            {[
              'Validación de habilidades con retos reales',
              'Networking directo con socios estratégicos',
              'Sellos de certificación validados por la UPeU',
              'Ranking académico regional'
            ].map((text) => (
              <div key={text} className="flex items-center gap-4 text-white font-bold">
                <CheckCircle2 size={24} className="text-blue-200" />
                <span>{text}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="text-sm text-blue-100 italic font-bold">
          * Requiere correo institucional (@upeu.edu.pe).
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center p-8 bg-white">
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="w-full max-w-lg space-y-10"
        >
          <div className="space-y-4">
            <h3 className="text-4xl font-bold text-slate-900 tracking-tight">Solicitar Acceso</h3>
            <p className="text-slate-400 font-medium font-serif italic text-lg leading-relaxed">Únete a los mejores talentos de tu facultad.</p>
          </div>

          <form className="grid grid-cols-2 gap-6" onSubmit={(e) => e.preventDefault()}>
            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-widest font-bold text-slate-400">Nombre</label>
              <input 
                type="text" 
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 focus:border-blue-500 focus:bg-white outline-none transition-all font-medium"
                placeholder="Juan"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-widest font-bold text-slate-400">Apellido</label>
              <input 
                type="text" 
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 focus:border-blue-500 focus:bg-white outline-none transition-all font-medium"
                placeholder="Diego"
              />
            </div>
            
            <div className="col-span-2 space-y-2">
              <label className="text-[10px] uppercase tracking-widest font-bold text-slate-400">Email Universitario</label>
              <input 
                type="email" 
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 focus:border-blue-500 focus:bg-white outline-none transition-all font-medium"
                placeholder="juan.diego@upeu.edu.pe"
              />
            </div>

            <div className="col-span-2 space-y-2">
              <label className="text-[10px] uppercase tracking-widest font-bold text-slate-400">Facultad / Carrera Principal</label>
              <select className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 focus:border-blue-500 focus:bg-white outline-none transition-all appearance-none text-slate-500 font-medium">
                <option>Selecciona tu carrera</option>
                <option>Ingeniería de Sistemas</option>
                <option>Ciencias de la Salud</option>
                <option>Administración & Negocios</option>
                <option>Educación & Teología</option>
                <option>Ingeniería Civil & Arquitectura</option>
              </select>
            </div>

            <div className="col-span-2 flex items-center gap-4 text-xs text-slate-500 mt-4 leading-relaxed font-medium">
              <input type="checkbox" className="w-4 h-4 rounded border-slate-200 bg-slate-50 accent-blue-600" />
              <span>Acepto los términos de servicio y la política de privacidad académica de SkillMatch UPeU.</span>
            </div>

            <Link 
               to="/dashboard"
              className="col-span-2 text-center bg-slate-900 text-white hover:bg-blue-600 py-4 rounded-xl font-bold transition-all shadow-xl shadow-slate-900/10"
            >
              Crear mi Perfil de Talento
            </Link>
          </form>

          <p className="text-center text-sm text-slate-500 font-medium">
            ¿Ya tienes una cuenta? <Link to="/login" className="text-blue-600 font-bold underline">Iniciar Sesión</Link>
          </p>

          <Link to="/" className="flex items-center gap-2 text-slate-400 hover:text-blue-600 transition-colors text-xs uppercase tracking-widest font-bold">
            <ArrowLeft size={16} />
            Volver
          </Link>
        </motion.div>
      </div>
    </div>
  );
}
