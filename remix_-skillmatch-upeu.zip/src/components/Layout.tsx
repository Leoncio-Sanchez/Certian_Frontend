import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import { motion } from 'framer-motion';

export default function Layout() {
  return (
    <div className="flex h-screen overflow-hidden bg-white text-slate-900">
      <Sidebar />
      <main className="flex-1 overflow-y-auto bg-slate-50 p-6 lg:p-10">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: "easeOut" }}
        >
          <Outlet />
        </motion.div>
      </main>
    </div>
  );
}
