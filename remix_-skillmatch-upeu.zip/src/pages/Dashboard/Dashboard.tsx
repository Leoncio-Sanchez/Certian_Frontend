import { useState } from 'react';
import { 
  Sparkles, 
  TrendingUp, 
  Target, 
  Award,
  Zap,
  ArrowUpRight,
  MessageSquare,
  Trophy,
  Clock
} from 'lucide-react';
import { motion } from 'framer-motion';

export default function Dashboard() {
  const [advice, setAdvice] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const getAIAdvice = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/ai/career-advice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          skills: ['React', 'TypeScript', 'Design Systems'], 
          interests: ['Fintech', 'SaaS', 'UI/UX'] 
        })
      });
      const data = await res.json();
      setAdvice(data.advice);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-10 pb-20 px-4 max-w-7xl mx-auto">
      {/* Hero Header */}
      <section className="relative overflow-hidden rounded-3xl bg-white p-10 lg:p-16 border border-slate-200 shadow-sm transition-all hover:shadow-md">
        <div className="absolute top-0 right-0 w-1/2 h-full opacity-10 pointer-events-none">
          <div className="absolute inset-0 bg-radial-gradient from-blue-600/30 to-transparent blur-3xl" />
        </div>
        
        <div className="relative z-10 max-w-2xl">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <span className="section-label">Bienvenido de nuevo, Juan Delgado</span>
            <h1 className="text-5xl lg:text-6xl font-bold text-slate-900 leading-tight mt-2 tracking-tight">
              Acelera tu talento <br />
              <span className="text-blue-600 italic font-medium">con retos reales.</span>
            </h1>
            <p className="text-slate-500 mt-6 text-lg font-medium leading-relaxed">
              Has validado <span className="text-blue-700 font-bold">140 horas</span> esta semana. <br />
              Estás a solo <span className="text-slate-900 font-bold">60 horas</span> de tu próximo certificado oficial.
            </p>
            
            <div className="flex gap-4 mt-10">
              <button className="bg-blue-600 text-white px-10 py-4 rounded-xl font-bold transition-all hover:bg-blue-700 shadow-lg shadow-blue-600/20 active:scale-95">
                Explorar Retos
              </button>
              <button className="bg-slate-50 text-slate-700 px-10 py-4 rounded-xl font-bold border border-slate-200 hover:bg-slate-100 transition-all active:scale-95">
                Mi Progreso
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats Grid */}
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Horas Validadas', value: '140h', icon: Clock, color: 'bg-blue-50 text-blue-600' },
          { label: 'Posición Ranking', value: '#5', icon: Trophy, color: 'bg-amber-50 text-amber-600' },
          { label: 'Sellos UPeU', value: '8', icon: Award, color: 'bg-emerald-50 text-emerald-600' },
          { label: 'Retos Activos', value: '2', icon: Target, color: 'bg-rose-50 text-rose-600' },
        ].map((stat, i) => (
          <motion.div 
            key={stat.label}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white p-6 border border-slate-200 rounded-2xl flex items-center justify-between hover:border-blue-200 transition-all shadow-sm group"
          >
            <div>
              <p className="section-label mb-1">{stat.label}</p>
              <h3 className="text-3xl font-bold text-slate-900">{stat.value}</h3>
            </div>
            <div className={`p-4 rounded-2xl transition-transform group-hover:scale-110 ${stat.color}`}>
              <stat.icon size={28} />
            </div>
          </motion.div>
        ))}
      </section>

      {/* Recommendations & AI */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        <section className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between px-2">
            <h2 className="text-2xl font-bold text-slate-800">Retos Recomendados</h2>
            <button className="text-blue-600 text-sm font-bold flex items-center gap-1 hover:underline">
              Ver Catálogo <ArrowUpRight size={16} />
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              { title: 'Optimización de Algoritmos', company: 'Google', hours: 40, duration: '40 medio', img: 'https://images.unsplash.com/photo-1516116216624-53e697fedbea?auto=format&fit=crop&q=80&w=800' },
              { title: 'Diseño de Interfaz Premium', company: 'Apple', hours: 20, duration: '20 básico', img: 'https://images.unsplash.com/photo-1558655146-d09347e92766?auto=format&fit=crop&q=80&w=800' },
            ].map((challenge) => (
              <div key={challenge.title} className="bg-white rounded-3xl overflow-hidden group cursor-pointer border border-slate-200 hover:border-blue-300 transition-all duration-300 shadow-sm hover:shadow-xl">
                <div className="h-44 overflow-hidden relative bg-slate-50">
                  <img 
                    src={challenge.img} 
                    alt={challenge.title} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-md px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest text-blue-700 border border-blue-100 shadow-sm">
                    {challenge.hours} Horas
                  </div>
                </div>
                <div className="p-8 text-center">
                  <span className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">{challenge.company}</span>
                  <h3 className="text-xl font-bold mt-1 text-slate-900 group-hover:text-blue-700 transition-colors">{challenge.title}</h3>
                  <div className="bg-blue-50 text-blue-700 text-[10px] font-bold uppercase tracking-widest px-3 py-1 rounded-full inline-block mt-4">
                    Nivel: {challenge.duration}
                  </div>
                  <div className="mt-8">
                    <button className="w-full py-4 bg-slate-900 hover:bg-blue-700 text-white rounded-xl text-sm font-bold transition-all shadow-lg shadow-slate-900/10">
                      Ver Detalles del Reto
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="space-y-6">
          <div className="bg-[#f0f9ff] p-8 rounded-3xl border border-blue-100 relative overflow-hidden shadow-sm">
            <div className="absolute -right-6 -top-6 w-32 h-32 bg-blue-200/50 blur-3xl rounded-full" />
            
            <div className="flex items-center gap-3 mb-6 relative">
              <div className="p-3 rounded-2xl bg-blue-600 text-white shadow-lg shadow-blue-600/30">
                <Sparkles size={24} />
              </div>
              <h2 className="text-xl font-bold text-slate-900">Career Assistant</h2>
            </div>
            
            <p className="text-slate-500 text-sm font-medium leading-relaxed mb-8 relative">
              SkillMatch AI ha analizado tu historial de retos. ¿Deseas optimizar tu ruta hacia las 200 horas?
            </p>

            {advice ? (
              <motion.div 
                initial={{ opacity: 0 }} 
                animate={{ opacity: 1 }}
                className="bg-white border border-blue-100 p-5 rounded-2xl text-slate-700 text-sm font-medium leading-relaxed shadow-sm max-h-[300px] overflow-y-auto"
              >
                {advice}
              </motion.div>
            ) : (
              <button 
                onClick={getAIAdvice}
                disabled={loading}
                className="w-full flex items-center justify-center gap-2 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold transition-all shadow-lg shadow-blue-600/20 active:scale-95 disabled:opacity-50"
              >
                {loading ? 'Consultando...' : 'Obtener Ruta Optimizada'}
                {!loading && <MessageSquare size={18} />}
              </button>
            )}
            
            <div className="mt-8 pt-8 border-t border-blue-100 relative">
              <p className="section-label uppercase text-blue-400">Siguiente Meta Sugerida</p>
              <div className="flex items-center gap-4 mt-4">
                <div className="w-14 h-14 rounded-2xl border-2 border-dashed border-blue-300 flex items-center justify-center">
                  <TrendingUp size={24} className="text-blue-300" />
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-900">Sello Arquitectura Cloud</p>
                  <p className="text-[11px] text-slate-400 font-bold uppercase tracking-tight">Vía Amazon Web Services</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
            <h3 className="font-bold text-lg mb-6 text-slate-900 border-b border-slate-100 pb-4">Conexiones Recientes</h3>
            <div className="space-y-6">
              {[
                { name: 'Sofia Rodriguez', action: 'validó un nuevo sello', time: 'hace 2h', avatar: 'SR' },
                { name: 'Admin Staff', action: 'publicó reto de 80h', time: 'hace 5h', avatar: 'AS' },
              ].map((activity, i) => (
                <div key={i} className="flex gap-4 items-center">
                  <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-[10px] font-bold text-slate-600 border border-slate-200">
                    {activity.avatar}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-slate-600 leading-snug"><span className="font-bold text-slate-900">{activity.name}</span> <br /> {activity.action}</p>
                    <p className="text-[10px] text-slate-400 font-bold uppercase mt-0.5 tracking-tighter">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
